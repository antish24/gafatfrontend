import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Descriptions, Spin, Alert, Select, Button, message, Switch, Form, Input, Space } from 'antd';
import axios from 'axios';
import { BACKENDURL } from '../../../helper/Urls';

const { Option } = Select;

const ProjectDetail = () => {
  const { id } = useParams(); // Get project ID from the URL params
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [employeeList, setEmployeeList] = useState([]); // List of available employees
  const [selectedEmployees, setSelectedEmployees] = useState([]); // Selected employees for assignment
  const [assignedEmployees, setAssignedEmployees] = useState([]); // Assigned employees
  const [team, setTeam] = useState([]); // Team members

  // Fetch project details and employee list on mount
  useEffect(() => {
    const fetchProjectDetail = async () => {
      try {
        const projectResponse = await axios.get(`${BACKENDURL}/project/${id}`);
        setProject(projectResponse.data.project);
        setAssignedEmployees(projectResponse.data.projectEmp.map(e => e.employee)); // Set the assigned employees

        const employeeResponse = await axios.get(`${BACKENDURL}/project/employees/all`); // Fetch available employees
        setEmployeeList(employeeResponse.data); // Set the employee list

        // Fetch team members from backend
        const teamResponse = await axios.get(`${BACKENDURL}/project/${id}/team`);
        setTeam(teamResponse.data.team); // Set the team from the backend

        setLoading(false);
      } catch (error) {
        setError('Failed to fetch project details or employee list');
        setLoading(false);
      }
    };

    fetchProjectDetail();
  }, [id]);

  // Handle assigning employees to the project
  const handleAssignEmployees = async () => {
    try {
      const response = await axios.post(`${BACKENDURL}/project/${id}/assign-employees`, {
        employeeIds: selectedEmployees,
      });
      message.success('Employees assigned successfully!');
      
      // Update project details and assigned employees after assignment
      setProject(response.data);
      setAssignedEmployees(response.data.employees.map(e => e.employee)); 
    } catch (error) {
      message.error('Failed to assign employees');
    }
  };

  // Handle status toggle (active/terminated) for employees
  const handleStatusChange = async (employeeId, isActive) => {
    try {
      await axios.post(`${BACKENDURL}/project/${id}/update-employee-status`, {
        employeeId,
        status: isActive ? 'Active' : 'Terminated',
      });

      // Update the local state to reflect the status change
      setAssignedEmployees((prevEmployees) =>
        prevEmployees.map((employee) =>
          employee.id === employeeId ? { ...employee, status: isActive ? 'Active' : 'Terminated' } : employee
        )
      );

      message.success(`Employee status updated to ${isActive ? 'Active' : 'Terminated'}`);
    } catch (error) {
      message.error('Failed to update employee status');
    }
  };

  // Handle adding a team member
  const handleAddTeamMember = () => {
    setTeam([...team, { role: '', employeeId: null }]);
  };

  // Handle change in team member role or employee
  const handleTeamChange = (index, field, value) => {
    const newTeam = [...team];
    newTeam[index][field] = value;
    setTeam(newTeam);
  };

  // Handle removing a team member
const handleRemoveTeamMember = async (index) => {
  const teamMemberToRemove = team[index];

  try {
    // Send request to backend to remove team member (adjust endpoint as needed)
    await axios.delete(`${BACKENDURL}/project/${id}/remove-team-member`, {
      data: { employeeId: teamMemberToRemove.employeeId }, // Pass employeeId to backend
    });

    // Remove team member from local state after successful removal
    const newTeam = team.filter((_, i) => i !== index);
    setTeam(newTeam);

    message.success('Team member removed successfully!');
  } catch (error) {
    message.error('Failed to remove team member');
  }
};


  // Handle form submission for adding team members
  const handleTeamSubmit = async () => {
    try {
      // Send team data to the backend (adjust endpoint as necessary)
      await axios.post(`${BACKENDURL}/project/${id}/add-team`, { team });
      message.success('Team members added successfully!');
    } catch (error) {
      message.error('Failed to add team members');
    }
  };

  if (loading) {
    return <Spin tip="Loading project details..." />;
  }

  if (error) {
    return <Alert message={error} type="error" />;
  }

  return (
    <>
      {project && (
        <>
          <Descriptions title="Project Details" bordered>
            <Descriptions.Item label="Site Name">{project.site}</Descriptions.Item>
            <Descriptions.Item label="Company">{project.company}</Descriptions.Item>
            <Descriptions.Item label="From">{project.startDate}</Descriptions.Item>
            <Descriptions.Item label="To">{project.endDate}</Descriptions.Item>
            <Descriptions.Item label="Price">{project.price}</Descriptions.Item>
            <Descriptions.Item label="Number of Employees">{project.noSecurity}</Descriptions.Item>
            <Descriptions.Item label="Attachments">
              {project.attachments ? (
                <a href={`/${project.attachments}`} target="_blank" rel="noopener noreferrer">
                  View Attachment
                </a>
              ) : (
                'No attachments'
              )}
            </Descriptions.Item>
          </Descriptions>
          
          <h2>Assign Employees</h2>
          <Select
            mode="multiple"
            style={{ width: '100%', marginBottom: '20px' }}
            placeholder="Select employees"
            onChange={(value) => setSelectedEmployees(value)} // Update selected employees
            value={selectedEmployees} // Maintain selected employees in the UI
          >
            {employeeList.map((employee) => (
              <Option key={employee.id} value={employee.id}>
                {employee.fName} {employee.lName}
              </Option>
            ))}
          </Select>
  
          <Button type="primary" onClick={handleAssignEmployees}>
            Assign Employees
          </Button>

          {/* Display the assigned employees */}
          <h2>Assigned Employees</h2>
          <ul>
            {assignedEmployees.map(employee => (
              <li
                key={employee.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '10px 0' // Add padding between list items for better readability
                }}
              >
                <span style={{ marginRight: '10px' }}> {/* Add some margin to space out the text */}
                  {employee.fName} {employee.lName}
                </span>
                <span style={{ marginRight: '10px' }}> {/* Add some margin between the switch and text */}
                  <Switch
                    checked={employee.status === 'Active'}
                    onChange={(checked) => handleStatusChange(employee.id, checked)}
                    checkedChildren="Active"
                    unCheckedChildren="Terminated"
                  />
                </span>
              </li>
            ))}
          </ul>

          {/* Team Section */}
          <h2>Team</h2>
          {team.map((member, index) => (
            <div key={index} style={{ marginBottom: '10px' }}>
              <Space size="large">
                <Select
                  value={member.role}
                  placeholder="Role"
                  style={{ width: 150 }}
                  onChange={(value) => handleTeamChange(index, 'role', value)}
                >
                  <Option value="Developer">Developer</Option>
                  <Option value="Designer">Designer</Option>
                  <Option value="Manager">Manager</Option>
                  {/* Add more roles as needed */}
                </Select>
                <Select
                  value={member.employeeId}
                  placeholder="Select Employee"
                  style={{ width: 150 }}
                  onChange={(value) => handleTeamChange(index, 'employeeId', value)}
                >
                  {employeeList.map((employee) => (
                    <Option key={employee.id} value={employee.id}>
                      {employee.fName} {employee.lName}
                    </Option>
                  ))}
                </Select>
                <Button type="danger" onClick={() => handleRemoveTeamMember(index)}>
                  Remove
                </Button>
              </Space>
            </div>
          ))}
          <Button type="dashed" onClick={handleAddTeamMember} style={{ marginBottom: '20px' }}>
            Add Team Member
          </Button>
          <Button type="primary" onClick={handleTeamSubmit}>
            Save Team
          </Button>
        </>
      )}
    </>
  );
};

export default ProjectDetail;