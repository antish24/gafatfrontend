export const BACKENDURL='https://erp-back-spb5.onrender.com'
// export const BACKENDURL='http://localhost:2024'
export const BLACKLISTAPI='http://localhost:2024'
export const UPLOADAPI='http://localhost:2024'